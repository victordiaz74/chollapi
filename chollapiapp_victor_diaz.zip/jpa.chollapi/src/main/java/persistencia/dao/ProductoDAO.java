package persistencia.dao;

import modelo.Producto;

public interface ProductoDAO extends GenericDAO<Producto,Long>{

}
