package persistencia.dao.impl;

import modelo.Producto;
import persistencia.dao.ProductoDAO;

public class ProductoDAOImplJpa extends GenericDAOImplJpa<Producto,Long> implements ProductoDAO {

}