package presentacion;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import modelo.Oferta;
import modelo.Producto;
import persistencia.dao.OfertaDAO;
import persistencia.dao.impl.OfertaDAOImplJpa;
import persistencia.jpa.Utilidades;

public class OfertaController {
	
	OfertaDAO ofertaDAO;
	EntityManager em = Utilidades.getEntityManagerFactory().createEntityManager();
	
	public OfertaController() {
		ofertaDAO = new OfertaDAOImplJpa();
	}
	
	public void crearOferta(Oferta oferta) {

		List<Oferta> listaOfertas = ofertaDAO.findAll();
		if(existe(listaOfertas, oferta)) {
			System.out.println("Oferta existente");
			
		}else {
			ofertaDAO.persist(oferta);
			System.out.println("Oferta creada correctamente");
		}
		
	}
	
	public boolean existe(List<Oferta> listaOfertas, Oferta oferta) {
		
		for(Oferta of: listaOfertas) {
			Date fechaOferta = of.getFechaPublicacion();
			String url = of.getUrl();
			Boolean disponible = of.isDisponible();
			
			if(fechaOferta.equals(oferta.getFechaPublicacion())) {
				if(url.equals(oferta.getUrl())) {
					if(disponible.equals(oferta.isDisponible())) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public List<Oferta> ultimas5(Long idProducto) {
		return ofertaDAO.ultimas5(idProducto);
	}
	
	public List<Oferta> ultimas10() {
		return ofertaDAO.ultimas10();
	}

}
