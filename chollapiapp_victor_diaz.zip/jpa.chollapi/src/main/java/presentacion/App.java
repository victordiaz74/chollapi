package presentacion;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;

import modelo.Oferta;
import modelo.Producto;
import persistencia.jpa.Utilidades;

//ESTE ES EL BUENO, EN EL APPDAO ESTA CON MENÚ
public class App {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void main( String[] args ){
		

		EntityManager em = null; 
		
		try {
			em = Utilidades.getEntityManagerFactory().createEntityManager();
			
			Oferta oferta = new Oferta();
			oferta.setUrl("paquito1.com");
			oferta.setFechaPublicacion(new SimpleDateFormat("dd-MM-yyyy").parse("26-03-2023"));
			oferta.setPrecio(25.0f);
			oferta.setDisponible(true);
			Producto producto = new Producto();
			producto.setNombre("CamisetaDelMadrid");
			producto.setIdFabricante(12345l);
			OfertaController ofertaController = new OfertaController();
			oferta.addProducto(producto);
			
			
			Oferta oferta1 = new Oferta();
			oferta1.setUrl("paquito1.com");
			oferta1.setFechaPublicacion(new SimpleDateFormat("dd-MM-yyyy").parse("26-05-2023"));
			oferta1.setPrecio(25.0f);
			oferta1.setDisponible(true);
			
			oferta1.addProducto(producto);
			
			ofertaController.crearOferta(oferta);
			ofertaController.crearOferta(oferta1);
			
			System.out.println(ofertaController.ultimas5(7l));
			System.out.println(ofertaController.ultimas10());
			
		} catch (Exception e ) {
			if (em != null) {
				e.printStackTrace();
				System.out.println("Se va a hacer rollback de la transacción");
				em.getTransaction().rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
			
		//cerrar
		Utilidades.closeEntityManagerFactory();
		
	}

}
