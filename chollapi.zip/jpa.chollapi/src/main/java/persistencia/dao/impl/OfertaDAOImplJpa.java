package persistencia.dao.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import modelo.Oferta;
import modelo.Producto;
import persistencia.dao.OfertaDAO;
import persistencia.jpa.Utilidades;

public class OfertaDAOImplJpa extends GenericDAOImplJpa<Oferta,Integer> implements OfertaDAO {
	EntityManager em = Utilidades.getEntityManagerFactory().createEntityManager();
	
	public List<Oferta> ultimas10() {
		
		List<Oferta> ofertas = em.createQuery("SELECT o FROM Oferta as o ORDER BY o.fechaPublicacion DESC").setMaxResults(10).getResultList();
		
		return ofertas;
	}

	public List<Oferta> ultimas5(Long idProducto) {
		
		Query query = em.createQuery("SELECT o FROM Oferta as o JOIN o.productos as p where p.idProducto = :idProducto ORDER BY o.fechaPublicacion DESC").setMaxResults(5);
		
		List<Oferta> ofertas = query.setParameter("idProducto", idProducto).getResultList();
		
		return ofertas;
	}

	public boolean crearOferta(Oferta oferta) { 

		em.persist(oferta);

		System.out.println(oferta);
		return true;
		
	}
}

