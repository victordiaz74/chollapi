package presentacion;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import modelo.Oferta;
import modelo.Producto;
import persistencia.dao.OfertaDAO;
import persistencia.dao.impl.OfertaDAOImplJpa;
import persistencia.jpa.Utilidades;

public class OfertaController {
	
	OfertaDAO ofertaDAO;
	EntityManager em = Utilidades.getEntityManagerFactory().createEntityManager();
	
	public OfertaController() {
		ofertaDAO = new OfertaDAOImplJpa();
	}
	
	public boolean crearOferta(Oferta oferta) {
		boolean ofertaCreada = false;
		List<Oferta> listaOfertas = ofertaDAO.findAll();
		for(Oferta of: listaOfertas) {
			Date fechaOferta = of.getFechaPublicacion();
			String url = of.getUrl();
			Boolean disponible = of.isDisponible();
			
			if(fechaOferta.equals(oferta.getFechaPublicacion())) {
				if(url.equals(oferta.getUrl())) {
					if(disponible.equals(oferta.isDisponible())) {
						ofertaCreada = false;
					}
				}
			}else {
				
				ofertaDAO.crearOferta(oferta);
				ofertaCreada = true;
			}
		}
		
		return ofertaCreada;
		
	}

	public List<Oferta> ultimas5(Long idProducto) {
		return ofertaDAO.ultimas5(idProducto);
	}
	
	public List<Oferta> ultimas10() {
		return ofertaDAO.ultimas10();
	}

}
